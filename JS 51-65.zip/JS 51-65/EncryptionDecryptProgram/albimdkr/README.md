# Encryption-Synchronous-AlbiMudakarNasyabi

Screen Shoot Program Encryption Decryption Synchronous (symmetric)
![1. Default](https://github.com/albimdkr/Encryption-Synchronous-AlbiMudakarNasyabi/blob/master/screenshot/1-Default-tampilan.png)

![2. Process program if running](https://github.com/albimdkr/Encryption-Synchronous-AlbiMudakarNasyabi/blob/master/screenshot/2-Proses-berhasil.png) 

![3. If process failed the field are empty](https://github.com/albimdkr/Encryption-Synchronous-AlbiMudakarNasyabi/blob/master/screenshot/3-Jika-proses-gagal-karna-field-kosong.png) 


