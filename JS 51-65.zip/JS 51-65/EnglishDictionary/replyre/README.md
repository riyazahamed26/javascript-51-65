# Eng_Dictionary
An interactive dictionary UI which provides meanings, synonyms and pronounces the word.

## features :
* provides meaning, pronunciation and synonyms along with examples.
* a pronunciation button which tells how to pronunce the word.
* clicking on synonym provides the meaning of that word.

## limitations:
* only one meaning is provided.
* API used has a lot of missing informations.

## ScreenShort: 
![Screenshot (219)](https://github.com/replyre/Eng_Dictionary/assets/121796450/74219858-7bcd-48fa-9b67-dc56a4daedd8)
