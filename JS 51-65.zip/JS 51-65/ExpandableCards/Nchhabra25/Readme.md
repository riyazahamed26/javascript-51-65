# Expandable Cards
![image](https://github.com/Nchhabra25/Gradient-Generator/assets/124149051/b55053a9-b686-43cc-8cae-19b3c43e0467)
