# Dad Joke Generator

Take a break and get some laughs with Dad's joke generator :)

![Project Snapshot!](./screenshot.png 'Project Snapshot')

## Instructions

run

```
  npm install
```

then

```
 npm start
```
